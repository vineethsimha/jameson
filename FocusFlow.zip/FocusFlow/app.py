import streamlit as st
import google.generativeai as genai
from pathlib import Path  

genai.configure(api_key="AIzaSyBdlQksMSSxo-zYv3-viYcs2xalhNBbvhA")

st.set_page_config(page_title="UNME", page_icon=Path("logo.jpg"))
st.markdown(
    """
    <style>
        /* Multi-Color Gradient Background */
        html, body, [data-testid="stAppViewContainer"] {
            background: linear-gradient(45deg, #ff6a00, #ee0979, #833ab4, #2ebf91, #141E30);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            color: white;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Move Image to Left */
        .image-container {
            position: absolute;
            left: -100px; /* Adjust this value to move further left */
            top: 100px;  /* Adjust the top position */
            width: 250px; /* Image width */
        }
    </style>
    """,
    unsafe_allow_html=True
)


st.markdown('<h1 style="text-align:center;">📚 GenAI-Powered Study Planner</h1>', unsafe_allow_html=True)

with st.container():
    col1, col2 = st.columns([0.7, 2])  
    
    with col1:
        st.markdown('<div class="image-container">', unsafe_allow_html=True)
        st.image("akshaya.jpg", width=500 )  
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        age = st.number_input("🙎 Enter learner's age", min_value=6, max_value=80, step=1)

    subject = st.text_area("📖 Enter the subject (Required)")
    topic = st.text_area("📌 Enter the topic of your subject (Required)")
    complexity = st.selectbox("📊 Select the complexity", ["Beginner", "Intermediate", "Advanced"])
    plan_duration = st.selectbox("⏳ Choose your duration", ["1 week", "10 days", "15 days", "20 days", "1 month"])

if st.button("✨ Generate Schedule"):
    if not subject.strip():
        st.error("❌ Please enter a subject before generating the study plan!")
    elif not topic.strip():
        st.error("❌ Please enter a topic before generating the study plan!")
    else:
        with st.spinner("Generating your study plan... ⏳"):
            try:
                
                prompt = (
                    f"You are an expert tutor. Create a detailed study schedule for a {age}-year-old "
                    f"student to study {subject} on the topic '{topic}' at a {complexity} level. "
                    f"The schedule should be designed for {plan_duration}. Provide daily study plans "
                    f"with key topics covered, study techniques, and tips for better understanding."
                )

                
                model = genai.GenerativeModel(model_name="gemini-pro")
                response = model.generate_content(prompt)

                
                lesson_plan = response.text if hasattr(response, "text") else "⚠ Error generating response. Please try again."

                
                st.subheader("📅 Generated Study Schedule")
                st.markdown(f'<div style="background:rgba(0,0,0,0.3); padding:10px; border-radius:10px;">{lesson_plan}</div>', unsafe_allow_html=True)

            except Exception as e:
                st.error(f"❌ API Error: {str(e)}")